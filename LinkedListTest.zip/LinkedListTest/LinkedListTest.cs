using NUnit.Framework;
using SinglyLinkedList;
using System;

namespace LinkedListTests
{
    [TestFixture]
    public class LinkedListTests
    {
        private LinkedList _list;

        [SetUp]
        public void Setup()
        {
            _list = new LinkedList();
        }

        [Test]
        public void AddFirst_ShouldAddNodeAtBeginning()
        {
            _list.AddFirst("Jane Doe");
            Assert.AreEqual(1, _list.Count);
            Assert.AreEqual("Jane Doe", _list.GetValue(0));
        }

        [Test]
        public void AddLast_ShouldAddNodeAtEnd()
        {
            _list.AddLast("John Smith");
            Assert.AreEqual(1, _list.Count);
            Assert.AreEqual("John Smith", _list.GetValue(0));
        }

        [Test]
        public void RemoveFirst_ShouldRemoveNodeFromBeginning()
        {
            _list.AddFirst("Jane Doe");
            _list.AddFirst("Joe Blow");
            _list.RemoveFirst();
            Assert.AreEqual(1, _list.Count);
            Assert.AreEqual("Jane Doe", _list.GetValue(0));
        }

        [Test]
        public void RemoveLast_ShouldRemoveNodeFromEnd()
        {
            _list.AddLast("Jane Doe");  // Add to end first
            _list.AddLast("Joe Blow");  // Then add another to end
            _list.RemoveLast();         // Remove last ("Joe Blow")
            Assert.AreEqual(1, _list.Count);
            Assert.AreEqual("Jane Doe", _list.GetValue(0)); // Now correct
        }

        [Test]
        public void GetValue_ShouldReturnCorrectValueAtIndex()
        {
            _list.AddFirst("Jane Doe");
            _list.AddFirst("Joe Blow");
            Assert.AreEqual("Joe Blow", _list.GetValue(0));  // First item is newest
            Assert.AreEqual("Jane Doe", _list.GetValue(1)); // Second item is older
        }

        [Test]
        public void Count_ShouldReturnCorrectSize()
        {
            Assert.AreEqual(0, _list.Count);
            _list.AddFirst("Jane Doe");
            Assert.AreEqual(1, _list.Count);
            _list.AddLast("John Smith");
            Assert.AreEqual(2, _list.Count);
        }

        [Test]
        public void PopulateListWithNames()
        {
            var names = new[]
            {
                "Joe Blow", "Joe Schmoe", "John Smith", "Jane Doe",
                "Bob Bobberson", "Sam Sammerson", "Dave Daverson"
            };

            // Clear the list before populating to ensure a fresh start
            _list = new LinkedList();

            foreach (var name in names)
            {
                _list.AddLast(name); // Adds each name at the end
            }

            // Verify the list contains the correct number of elements
            Assert.AreEqual(names.Length, _list.Count);

            // Verify the order of elements
            for (int i = 0; i < names.Length; i++)
            {
                Assert.AreEqual(names[i], _list.GetValue(i), $"Mismatch at index {i}");
            }
        }

        [Test]
        public void GetValue_ShouldThrowExceptionForInvalidIndex()
        {
            Assert.Throws<IndexOutOfRangeException>(() => _list.GetValue(0));
        }

        [Test]
        public void RemoveFirst_ShouldThrowExceptionWhenListIsEmpty()
        {
            Assert.Throws<InvalidOperationException>(() => _list.RemoveFirst());
        }

        [Test]
        public void RemoveLast_ShouldThrowExceptionWhenListIsEmpty()
        {
            Assert.Throws<InvalidOperationException>(() => _list.RemoveLast());
        }
    }
}
