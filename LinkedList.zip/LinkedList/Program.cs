﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System;
using SinglyLinkedList; // Namespace of your class library

class Program
{
    static void Main(string[] args)
    {
        // Create a LinkedList instance
        LinkedList list = new LinkedList();

        // Add nodes to the list
        list.AddFirst("Node 1");
        list.AddLast("Node 2");

        // Display all the nodes
        Node current = list.Head;
        while (current != null)
        {
            Console.WriteLine(current.Value);
            current = current.Next;
        }
    }
}

