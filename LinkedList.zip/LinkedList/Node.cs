﻿namespace SinglyLinkedList
{
    public class Node
    {
        // Private fields
        private string _value;
        private Node _next;

        // Property to get and set the value
        public string Value
        {
            get { return _value; }
            set { _value = value; }
        }

        // Property to get and set the next node
        public Node Next
        {
            get { return _next; }
            set { _next = value; }
        }

        // Default constructor
        public Node()
        {
            _value = string.Empty;
            _next = null;
        }

        // Constructor with value
        public Node(string value)
        {
            _value = value;
            _next = null;
        }

        // Constructor with value and next node
        public Node(string value, Node next)
        {
            _value = value;
            _next = next;
        }
    }
}
